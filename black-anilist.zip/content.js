// AniList Black Theme with settings
const DEFAULTS = {
    enabled: true,
    username: "#ececec",
    link: "#8fa6ff",
    bg: "#000000",
    card: "#0d0d0d",
    hideFooter: false,
    hideBanner: false,
    hideForum: false,
    wide: false,
    font: "default"
};

function rgb(hex) {
    const n = parseInt(hex.slice(1), 16);
    return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}`;
}

const BASE_CSS = `
html, body, #app {
    background: var(--ap-bg) !important;
    background-color: var(--ap-bg) !important;
    color: #ececec !important;
}

:where(#app > div),
:where(body > div),
:where(.page-content),
:where(.page-content > div),
:where(.search-page-unscoped),
:where(.search-page),
:where(.content),
:where(.container) {
    background-color: var(--ap-bg) !important;
}

body::before, body::after,
#app::before, #app::after,
.page-content::before, .page-content::after {
    background: var(--ap-bg) !important;
}

.nav, .footer { background: var(--ap-card) !important; }

.home .activity-feed-wrap,
.home .list-wrap,
.home .forum-activity,
.home .list-preview-wrap {
    background: transparent !important;
    box-shadow: none !important;
}

.home .activity-feed-wrap .activity-entry > .wrap,
.activity-entry > .wrap,
.activity-entry .wrap,
.activity-text .wrap,
.activity-message .wrap,
.activity-anime_list .wrap,
.activity-manga_list .wrap,
.activity-replies .reply,
.activity-markdown,
.activity-entry .reply,
.activity-entry .reply-wrap {
    background: var(--ap-card) !important;
    opacity: 1 !important;
    border-radius: 12px;
}

.about .wrap,
.about .content-wrap,
.favourites-wrap .wrap,
.media-preview-card,
.review-card,
.thread-card,
.thread-card .wrap,
.comment .wrap,
.card,
.dropdown,
.el-dropdown-menu,
.el-select-dropdown,
.tooltip,
.modal .wrap {
    background-color: var(--ap-card) !important;
    border-radius: 12px;
}

input, textarea, .el-input__inner, .markdown-editor {
    background-color: var(--ap-card) !important;
    color: #ececec !important;
    border-color: #262626 !important;
}

a { color: var(--ap-link); }

a.name,
.name-wrapper .name,
.name-wrapper h1.name,
.activity-entry .header .name,
.activity-entry .header a.name,
.reply .header .name,
.reply .header a.name,
.user-card .name,
.user-link,
.follow-card .name,
.thread-card .user a,
.comment .header a.name,
.hover-data .name,
a[href^="/user/"].name {
    color: var(--ap-username) !important;
}

.actions .list .add,
.actions .list .dropdown,
.actions .list .dropdown-toggle {
    background: #1a1a1a !important;
    color: #ececec !important;
}

.actions .list .dropdown .fa-angle-down,
.actions .list .dropdown .fa-chevron-down,
.actions .list .dropdown i,
.el-select .el-select__caret,
.el-select .el-input .el-icon,
.el-select .el-input .el-icon-arrow-up,
.el-select .el-input .el-icon-arrow-down {
    color: #ececec !important;
    fill: #ececec !important;
}

.actions .list .dropdown .dropdown-wrap,
.actions .list .dropdown .dropdown-wrap .item,
.el-select-dropdown,
.el-select-dropdown__item {
    background-color: var(--ap-card) !important;
    color: #ececec !important;
}

.actions .list .dropdown .dropdown-wrap .item:hover,
.el-select-dropdown__item.hover,
.el-select-dropdown__item:hover,
.filter-select .dropdown-wrap .option:hover,
.filter-select .dropdown-wrap .item:hover {
    background-color: #1a1a1a !important;
}

.el-popper .popper__arrow,
.el-popper .popper__arrow::after {
    border-bottom-color: var(--ap-card) !important;
    border-top-color: var(--ap-card) !important;
}

.filters, .filter-wrap, .filter-select, .filter-select .select-wrap,
.filter-select .dropdown, .filter-select .dropdown-wrap,
.filter-select .dropdown-wrap .option, .filter-select .dropdown-wrap .item,
.filter-select .el-input__inner, .search-input, .search-wrap,
.search-wrap input, .multi-select, .multi-select .options,
.tag-select, .tag-select .tag-wrap, .year-slider, .el-slider__runway,
.media-card, .results .media-card, .results.list .media-card,
.results.table .media-card, .media-card .title {
    background-color: var(--ap-card) !important;
    color: #ececec !important;
    border-color: #262626 !important;
}

.loading, .no-results, .results { background-color: transparent !important; }

.banner, .banner .shadow, .banner .container, .banner .content,
.banner .name-wrapper, .banner .overlay, .header-wrap .banner * {
    background-color: transparent !important;
    box-shadow: none !important;
}

.banner .avatar, .banner .avatar img { background-color: transparent !important; }

.activity-entry .activity-replies .reply,
.activity-replies .reply,
.comment-wrap .comment,
.comments .comment,
.child-comments .comment,
.thread-comments .comment {
    background-color: var(--ap-card) !important;
    border: 1px solid #262626 !important;
    border-left: 3px solid #262626 !important;
    border-radius: 10px !important;
    margin-bottom: 10px !important;
    padding: 10px 12px !important;
}

.activity-replies .reply .markdown,
.comment .markdown,
.comment .comment-markdown {
    background: transparent !important;
    color: #ececec !important;
}

.activity-replies, .child-comments, .comment-wrap .children {
    background: transparent !important;
    padding-left: 12px;
}
`;

const FONTS = {
    arial: "Arial, Helvetica, sans-serif",
    georgia: "Georgia, serif",
    mono: "Consolas, 'Courier New', monospace"
};

function build(s) {
    const card = rgb(s.card);
    const bg = rgb(s.bg);
    let css = `
    :root, html, body, #app, .site-theme-dark, .site-theme-contrast {
        --ap-username: ${s.username};
        --ap-link: ${s.link};
        --ap-bg: ${s.bg};
        --ap-card: ${s.card};

        --color-background: ${bg} !important;
        --color-background-300: ${bg} !important;
        --color-foreground: ${card} !important;
        --color-foreground-grey: ${card} !important;
        --color-foreground-grey-dark: ${card} !important;
        --color-foreground-blue: ${card} !important;
        --color-foreground-blue-dark: ${card} !important;
        --color-background-blue-dark: ${card} !important;
        --color-text: 236, 236, 236 !important;
        --color-text-light: 190, 190, 190 !important;
        --color-text-lighter: 150, 150, 150 !important;
        --color-overlay: 0, 0, 0 !important;
    }
    ` + BASE_CSS;

    if (s.hideFooter) css += `.footer { display: none !important; }\n`;
    if (s.hideBanner) css += `.banner { display: none !important; }\n`;
    if (s.hideForum) css += `.home .forum-activity { display: none !important; }\n`;
    if (s.wide) css += `.container, .page-content .container { max-width: 1600px !important; }\n`;
    if (FONTS[s.font]) {
        css += `body, button, input, textarea { font-family: ${FONTS[s.font]} !important; }\n`;
    }
    return css;
}
const styleEl = document.createElement("style");
styleEl.id = "anilist-black-theme";
(document.head || document.documentElement).appendChild(styleEl);

function load() {
    browser.storage.local.get(DEFAULTS).then((s) => {
        const css = s.enabled ? build(s) : "";
        if (styleEl.textContent !== css) styleEl.textContent = css;
    }).catch((e) => console.error("AniList Black:", e));
}

load();
browser.storage.onChanged.addListener(load);
browser.runtime.onMessage.addListener((m) => {
    if (m && m.type === "ap-update") load();
});
setInterval(load, 1500);
