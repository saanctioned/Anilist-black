const DEFAULTS = {
    enabled: true,
    username: "#ececec",
    link: "#8fa6ff",
    bg: "#000000",
    card: "#0d0d0d",
    hideFooter: false,
    hideBanner: false,
    hideForum: false,
    wide: false,
    font: "default"
};

const HEX = /^#[0-9a-fA-F]{6}$/;
const statusEl = document.getElementById("status");

function swatch(el) {
    if (el.classList.contains("hex") && HEX.test(el.value)) {
        el.style.borderLeftColor = el.value;
    }
}

function fill(s) {
    for (const k in DEFAULTS) {
        const el = document.getElementById(k);
        if (el.type === "checkbox") el.checked = s[k];
        else el.value = s[k];
        swatch(el);
    }
}

async function save(change) {
    try {
        await browser.storage.local.set(change);
        statusEl.textContent = "Saved ✓";
        const tabs = await browser.tabs.query({ url: "https://anilist.co/*" });
        for (const t of tabs) {
            browser.tabs.sendMessage(t.id, { type: "ap-update" }).catch(() => {});
        }
    } catch (e) {
        statusEl.textContent = "Error: " + e.message;
    }
}

browser.storage.local.get(DEFAULTS).then(fill).catch((e) => {
    statusEl.textContent = "Error: " + e.message;
});

document.addEventListener("input", (e) => {
    const el = e.target;
    if (!(el.id in DEFAULTS)) return;

    if (el.classList.contains("hex")) {
        let v = el.value.trim();
        if (v && v[0] !== "#") v = "#" + v;
        if (!HEX.test(v)) {
            statusEl.textContent = "Type a full hex code like #ff0000";
            return;
        }
        el.value = v;
        swatch(el);
        save({ [el.id]: v });
        return;
    }

    save({ [el.id]: el.type === "checkbox" ? el.checked : el.value });
});

document.getElementById("reset").addEventListener("click", () => {
    save(DEFAULTS).then(() => fill(DEFAULTS));
});
